#!/bin/bash -x

# Removing the guid used in the repo url defined in /etc/yum.repos.d/amzn2-core.repo
sed 's/-$guid//g' /etc/yum.repos.d/amzn2-core.repo -i

yum clean all

yum update \
    aws-cfn-bootstrap \
    amazon-ssm-agent \
    bind \
    binutils \
    ca-certificates \
    containerd \
    cpio \
    cri-tools \
    curl \
    docker \
    expat \
    freetype \
    gcc10-binutils \
    glib2 \
    glibc \
    grub2 \
    kernel \
    krb5 \
    less \
    libcap \
    libxml2 \
    microcode_ctl \
    ncurses \
    nerdctl \
    nghttp2 \
    openssl \
    openssh \
    python \
    python-idna \
    python-jinja2 \
    python-jwcrypto \
    python-pip \
    python-pillow \
    python-requests \
    python3 \
    python2-setuptools \
    python-urllib3 \
    runc \
    sysstat \
    systemd \
    util-linux \
    vim \
    vim-filesystem \
    -y

yum install openssl11 -y

